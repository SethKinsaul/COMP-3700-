import java.util.ArrayList;
import java.util.List;

public class ProductList {
    public List<Product> products = new ArrayList<>();
}